import React, { useEffect, useState } from "react";
import { View, Text, Button } from "react-native";
import axios from "axios";

const API_URL = "http://localhost:3000";

export default function App() {
  const [shifts, setShifts] = useState<any[]>([]);

  const createShift = async () => {
    await axios.post(`${API_URL}/shifts`, {
      operatorId: "op-1",
      date: new Date(),
      hours: 8
    });
    fetchShifts();
  };

  const fetchShifts = async () => {
    const res = await axios.get(`${API_URL}/shifts`);
    setShifts(res.data);
  };

  useEffect(() => {
    fetchShifts();
  }, []);

  return (
    <View style={{ padding: 40 }}>
      <Button title="Create Shift" onPress={createShift} />
      {shifts.map(s => (
        <Text key={s.id}>{s.operatorId} - {s.hours}h</Text>
      ))}
    </View>
  );
}
